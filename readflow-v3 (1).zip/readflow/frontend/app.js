/**
 * ReadFlow - Adaptive AI Reading Companion
 * 
 * Main application script that handles:
 * - WebSocket connection for real-time engagement data
 * - Webcam capture and frame streaming to backend
 * - Text-to-speech playback with adaptive voice
 * - Story management and reading progress
 * - UI state management
 */

class ReadFlowApp {
    constructor() {
        // Configuration
        this.config = {
            backendUrl: 'http://localhost:3001',
            wsUrl: 'ws://localhost:3001',
            frameInterval: 500, // Send frame every 500ms
            audioContext: null
        };

        // State
        this.state = {
            sessionId: null,
            isConnected: false,
            isReading: false,
            isPaused: true,
            webcamActive: false,
            currentStory: null,
            currentParagraph: 0,
            currentMood: 'calm',
            currentSpeed: 1.0,
            audioQueue: [],
            isPlayingAudio: false,
            currentAudio: null,  // Track current audio element
            notificationsEnabled: true,  // Toggle for notifications
            autoAdaptEnabled: true  // Toggle for auto voice adaptation
        };

        // DOM Elements
        this.elements = {};

        // WebSocket
        this.ws = null;
        this.frameInterval = null;

        // Webcam
        this.videoStream = null;

        // Initialize
        this.init();
    }

    /**
     * Initialize the application
     */
    async init() {
        this.cacheElements();
        this.bindEvents();
        this.connectWebSocket();
        
        // Initialize audio context on user interaction
        document.addEventListener('click', () => this.initAudioContext(), { once: true });
    }

    /**
     * Cache DOM elements for better performance
     */
    cacheElements() {
        this.elements = {
            // Screens
            welcomeScreen: document.getElementById('welcome-screen'),
            readingInterface: document.getElementById('reading-interface'),
            
            // Story elements
            storyTitle: document.getElementById('story-title'),
            readingText: document.getElementById('reading-text'),
            paragraphCount: document.getElementById('paragraph-count'),
            readingTime: document.getElementById('reading-time'),
            readingProgress: document.getElementById('reading-progress'),
            
            // Controls
            playBtn: document.getElementById('play-btn'),
            prevBtn: document.getElementById('prev-btn'),
            nextBtn: document.getElementById('next-btn'),
            newStoryBtn: document.getElementById('new-story-btn'),
            generateStoryBtn: document.getElementById('generate-story-btn'),
            uploadStoryBtn: document.getElementById('upload-story-btn'),
            analyzeBtn: document.getElementById('analyze-btn'),
            notificationToggle: document.getElementById('notification-toggle'),
            settingsBtn: document.getElementById('settings-btn'),
            
            // Webcam
            webcamContainer: document.getElementById('webcam-container'),
            webcamPlaceholder: document.getElementById('webcam-placeholder'),
            webcamVideo: document.getElementById('webcam-video'),
            webcamCanvas: document.getElementById('webcam-canvas'),
            webcamStatus: document.getElementById('webcam-status'),
            toggleWebcam: document.getElementById('toggle-webcam'),
            
            // Metrics
            metricFocus: document.getElementById('metric-focus'),
            metricEngagement: document.getElementById('metric-engagement'),
            metricStress: document.getElementById('metric-stress'),
            metricFatigue: document.getElementById('metric-fatigue'),
            focusBar: document.getElementById('focus-bar'),
            engagementBar: document.getElementById('engagement-bar'),
            stressBar: document.getElementById('stress-bar'),
            fatigueBar: document.getElementById('fatigue-bar'),
            
            // Mood
            moodIcon: document.getElementById('mood-icon'),
            moodName: document.getElementById('mood-name'),
            moodDescription: document.getElementById('mood-description'),
            moodBtns: document.querySelectorAll('.mood-btn'),
            speedSlider: document.getElementById('speed-slider'),
            speedValue: document.getElementById('speed-value'),
            
            // Modals
            generateModal: document.getElementById('generate-modal'),
            uploadModal: document.getElementById('upload-modal'),
            settingsModal: document.getElementById('settings-modal'),
            analyzeModal: document.getElementById('analyze-modal'),
            loadingOverlay: document.getElementById('loading-overlay'),
            loadingText: document.getElementById('loading-text'),
            
            // Settings Elements
            settingsNotificationsToggle: document.getElementById('notifications-toggle'),
            settingsSpeedSlider: document.getElementById('settings-speed-slider'),
            settingsSpeedValue: document.getElementById('settings-speed-value'),
            defaultMoodSelect: document.getElementById('default-mood-select'),
            autoAdaptToggle: document.getElementById('auto-adapt-toggle'),
            saveSettingsBtn: document.getElementById('save-settings-btn'),
            
            // Analyze Elements
            analyzeForm: document.getElementById('analyze-form'),
            analyzeSubject: document.getElementById('analyze-subject'),
            analyzeContent: document.getElementById('analyze-content'),
            analyzeLevel: document.getElementById('analyze-level'),
            
            // Forms
            generateForm: document.getElementById('generate-form'),
            uploadForm: document.getElementById('upload-form'),
            storyTopic: document.getElementById('story-topic'),
            readingLevel: document.getElementById('reading-level'),
            storyLength: document.getElementById('story-length'),
            ageGroup: document.getElementById('age-group'),
            uploadTitle: document.getElementById('upload-title'),
            uploadText: document.getElementById('upload-text'),
            
            // Toast
            encouragementToast: document.getElementById('encouragement-toast'),
            encouragementText: document.getElementById('encouragement-text')
        };
    }

    /**
     * Bind event listeners
     */
    bindEvents() {
        // Navigation buttons
        this.elements.generateStoryBtn.addEventListener('click', () => this.openModal('generate'));
        this.elements.uploadStoryBtn.addEventListener('click', () => this.openModal('upload'));
        this.elements.newStoryBtn.addEventListener('click', () => this.showWelcomeScreen());
        
        // Analyze button
        if (this.elements.analyzeBtn) {
            this.elements.analyzeBtn.addEventListener('click', () => this.openModal('analyze'));
        }
        
        // Settings button
        if (this.elements.settingsBtn) {
            this.elements.settingsBtn.addEventListener('click', () => this.openModal('settings'));
        }
        
        // Notification toggle (header button removed - now in settings)
        if (this.elements.notificationToggle) {
            this.elements.notificationToggle.addEventListener('click', () => this.openModal('settings'));
        }
        
        // Modal close buttons
        document.getElementById('close-generate-modal').addEventListener('click', () => this.closeModal('generate'));
        document.getElementById('close-upload-modal').addEventListener('click', () => this.closeModal('upload'));
        document.getElementById('close-settings-modal')?.addEventListener('click', () => this.closeModal('settings'));
        document.getElementById('close-analyze-modal')?.addEventListener('click', () => this.closeModal('analyze'));
        
        // Modal overlay click to close
        this.elements.generateModal.addEventListener('click', (e) => {
            if (e.target === this.elements.generateModal) this.closeModal('generate');
        });
        this.elements.uploadModal.addEventListener('click', (e) => {
            if (e.target === this.elements.uploadModal) this.closeModal('upload');
        });
        this.elements.settingsModal?.addEventListener('click', (e) => {
            if (e.target === this.elements.settingsModal) this.closeModal('settings');
        });
        this.elements.analyzeModal?.addEventListener('click', (e) => {
            if (e.target === this.elements.analyzeModal) this.closeModal('analyze');
        });
        
        // Forms
        this.elements.generateForm.addEventListener('submit', (e) => this.handleGenerateSubmit(e));
        this.elements.uploadForm.addEventListener('submit', (e) => this.handleUploadSubmit(e));
        this.elements.analyzeForm?.addEventListener('submit', (e) => this.handleAnalyzeSubmit(e));
        
        // Settings save button
        this.elements.saveSettingsBtn?.addEventListener('click', () => this.saveSettings());
        
        // Settings speed slider (live update)
        this.elements.settingsSpeedSlider?.addEventListener('input', (e) => {
            const value = parseFloat(e.target.value);
            if (this.elements.settingsSpeedValue) {
                this.elements.settingsSpeedValue.textContent = `${value.toFixed(1)}x`;
            }
        });
        
        // Analyze subject option cards
        document.querySelectorAll('#analyze-modal .option-card').forEach(card => {
            card.addEventListener('click', () => {
                document.querySelectorAll('#analyze-modal .option-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                if (this.elements.analyzeSubject) {
                    this.elements.analyzeSubject.value = card.dataset.value;
                }
            });
        });
        
        // Reading level option cards
        document.querySelectorAll('#generate-modal .option-card').forEach(card => {
            card.addEventListener('click', () => {
                document.querySelectorAll('#generate-modal .option-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                this.elements.readingLevel.value = card.dataset.value;
            });
        });
        
        // Playback controls
        this.elements.playBtn.addEventListener('click', () => this.togglePlayback());
        this.elements.prevBtn.addEventListener('click', () => this.previousParagraph());
        this.elements.nextBtn.addEventListener('click', () => this.nextParagraph());
        
        // Webcam toggle
        this.elements.toggleWebcam.addEventListener('click', () => this.toggleWebcam());
        this.elements.webcamPlaceholder.addEventListener('click', () => this.toggleWebcam());
        
        // Mood buttons
        this.elements.moodBtns.forEach(btn => {
            btn.addEventListener('click', () => this.setMood(btn.dataset.mood));
        });
        
        // Speed slider
        this.elements.speedSlider.addEventListener('input', (e) => {
            this.state.currentSpeed = parseFloat(e.target.value);
            this.elements.speedValue.textContent = `${this.state.currentSpeed.toFixed(1)}x`;
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    /**
     * Handle keyboard shortcuts
     */
    handleKeyboard(e) {
        // Only handle if reading interface is visible
        if (this.elements.readingInterface.style.display === 'none') return;
        
        switch (e.code) {
            case 'Space':
                e.preventDefault();
                this.togglePlayback();
                break;
            case 'ArrowLeft':
                this.previousParagraph();
                break;
            case 'ArrowRight':
                this.nextParagraph();
                break;
        }
    }

    /**
     * Initialize audio context (required for modern browsers)
     */
    initAudioContext() {
        if (!this.config.audioContext) {
            this.config.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
    }

    /**
     * Connect to WebSocket server
     */
    connectWebSocket() {
        try {
            this.ws = new WebSocket(this.config.wsUrl);
            
            this.ws.onopen = () => {
                console.log('WebSocket connected');
                this.state.isConnected = true;
            };
            
            this.ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleWebSocketMessage(data);
            };
            
            this.ws.onclose = () => {
                console.log('WebSocket disconnected');
                this.state.isConnected = false;
                this.state.sessionId = null;
                
                // Attempt reconnection after 3 seconds
                setTimeout(() => this.connectWebSocket(), 3000);
            };
            
            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
            };
        } catch (error) {
            console.error('Failed to connect WebSocket:', error);
            // Continue without real-time features
        }
    }

    /**
     * Handle incoming WebSocket messages
     */
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'connected':
                this.state.sessionId = data.sessionId;
                console.log('Session ID:', this.state.sessionId);
                break;
                
            case 'engagement_update':
                this.updateMetrics(data.data);
                if (data.adaptiveSettings) {
                    this.applyAdaptiveSettings(data.adaptiveSettings);
                }
                break;
                
            case 'adaptation':
                this.handleAdaptation(data);
                break;
                
            case 'pong':
                // Connection alive
                break;
        }
    }

    /**
     * Update engagement metrics UI
     */
    updateMetrics(metrics) {
        const formatPercent = (value) => Math.round(value * 100) + '%';
        
        if (metrics.focus !== undefined) {
            this.elements.metricFocus.textContent = formatPercent(metrics.focus);
            this.elements.focusBar.style.width = formatPercent(metrics.focus);
        }
        
        if (metrics.engagement !== undefined) {
            this.elements.metricEngagement.textContent = formatPercent(metrics.engagement);
            this.elements.engagementBar.style.width = formatPercent(metrics.engagement);
        }
        
        if (metrics.stress !== undefined) {
            this.elements.metricStress.textContent = formatPercent(metrics.stress);
            this.elements.stressBar.style.width = formatPercent(metrics.stress);
        }
        
        if (metrics.fatigue !== undefined) {
            this.elements.metricFatigue.textContent = formatPercent(metrics.fatigue);
            this.elements.fatigueBar.style.width = formatPercent(metrics.fatigue);
        }
        
        // LOCAL ADAPTATION: Determine mood based on current metrics
        this.adaptVoiceToMetrics(metrics);
    }
    
    /**
     * Adapt voice based on engagement metrics (client-side logic)
     */
    adaptVoiceToMetrics(metrics) {
        // Skip if auto-adapt is disabled
        if (!this.state.autoAdaptEnabled) return;
        
        const focus = metrics.focus || 0.5;
        const stress = metrics.stress || 0.3;
        const fatigue = metrics.fatigue || 0.3;
        const engagement = metrics.engagement || 0.5;
        
        let newMood = this.state.currentMood;
        let recommendation = '';
        
        // Decision logic - check conditions in priority order
        if (focus < 0.4) {
            newMood = 'energetic';
            recommendation = '🔥 Low focus detected - switching to energetic voice!';
        } else if (fatigue > 0.5) {
            newMood = 'soothing';
            recommendation = '🌙 Fatigue detected - switching to soothing voice';
        } else if (stress > 0.5) {
            newMood = 'soothing';
            recommendation = '😌 Stress detected - switching to calming voice';
        } else if (engagement < 0.45) {
            newMood = 'encouraging';
            recommendation = '💪 Engagement dropping - adding encouragement!';
        } else if (engagement > 0.7 && focus > 0.6) {
            newMood = 'expressive';
            recommendation = '🎭 Great engagement! Adding expressiveness';
        } else if (focus > 0.5 && stress < 0.3) {
            newMood = 'calm';
            recommendation = '😊 Good focus - maintaining steady pace';
        }
        
        // Only change if mood is different
        if (newMood !== this.state.currentMood) {
            console.log('Voice adaptation:', recommendation);
            this.setMood(newMood, true);
            this.showEncouragement(recommendation);
        }
    }

    /**
     * Apply adaptive settings from backend
     */
    applyAdaptiveSettings(settings) {
        if (settings.voice && settings.voice !== this.state.currentMood) {
            this.setMood(settings.voice, false); // Don't send to server
        }
        
        if (settings.speed && settings.speed !== this.state.currentSpeed) {
            this.state.currentSpeed = settings.speed;
            this.elements.speedSlider.value = settings.speed;
            this.elements.speedValue.textContent = `${settings.speed.toFixed(1)}x`;
        }
    }

    /**
     * Handle adaptation recommendations from AI
     */
    handleAdaptation(data) {
        console.log('Adaptation:', data.recommendation);
        
        // Update mood if changed
        if (data.mood && data.mood !== this.state.currentMood) {
            this.setMood(data.mood, false);
        }
        
        // Show encouragement if provided
        if (data.encouragement) {
            this.showEncouragement(data.encouragement);
        }
    }

    /**
     * Toggle webcam on/off
     */
    async toggleWebcam() {
        if (this.state.webcamActive) {
            this.stopWebcam();
        } else {
            await this.startWebcam();
        }
    }

    /**
     * Start webcam capture
     */
    async startWebcam() {
        try {
            this.videoStream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'user'
                }
            });
            
            this.elements.webcamVideo.srcObject = this.videoStream;
            this.elements.webcamVideo.style.display = 'block';
            this.elements.webcamPlaceholder.style.display = 'none';
            this.elements.webcamStatus.style.display = 'flex';
            this.elements.toggleWebcam.textContent = '🔴';
            
            this.state.webcamActive = true;
            
            // Start sending frames
            this.startFrameCapture();
            
        } catch (error) {
            console.error('Webcam error:', error);
            alert('Unable to access webcam. Please ensure you have granted camera permissions.');
        }
    }

    /**
     * Stop webcam capture
     */
    stopWebcam() {
        if (this.videoStream) {
            this.videoStream.getTracks().forEach(track => track.stop());
            this.videoStream = null;
        }
        
        this.elements.webcamVideo.style.display = 'none';
        this.elements.webcamPlaceholder.style.display = 'flex';
        this.elements.webcamStatus.style.display = 'none';
        this.elements.toggleWebcam.textContent = '👁️';
        
        this.state.webcamActive = false;
        
        // Stop frame capture
        if (this.frameInterval) {
            clearInterval(this.frameInterval);
            this.frameInterval = null;
        }
    }

    /**
     * Start capturing and sending video frames
     */
    startFrameCapture() {
        const canvas = this.elements.webcamCanvas;
        const video = this.elements.webcamVideo;
        const ctx = canvas.getContext('2d');
        
        this.frameInterval = setInterval(() => {
            if (!this.state.webcamActive || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
            
            // Set canvas size to match video
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            // Draw video frame to canvas
            ctx.drawImage(video, 0, 0);
            
            // Convert to base64 and send
            const frameData = canvas.toDataURL('image/jpeg', 0.5);
            
            this.ws.send(JSON.stringify({
                type: 'video_frame',
                frame: frameData
            }));
            
        }, this.config.frameInterval);
    }

    /**
     * Open a modal
     */
    openModal(modalType) {
        let modal;
        switch(modalType) {
            case 'generate':
                modal = this.elements.generateModal;
                break;
            case 'upload':
                modal = this.elements.uploadModal;
                break;
            case 'settings':
                modal = this.elements.settingsModal;
                this.loadSettingsToModal(); // Load current settings
                break;
            case 'analyze':
                modal = this.elements.analyzeModal;
                break;
        }
        if (modal) modal.classList.add('active');
    }

    /**
     * Close a modal
     */
    closeModal(modalType) {
        let modal;
        switch(modalType) {
            case 'generate':
                modal = this.elements.generateModal;
                break;
            case 'upload':
                modal = this.elements.uploadModal;
                break;
            case 'settings':
                modal = this.elements.settingsModal;
                break;
            case 'analyze':
                modal = this.elements.analyzeModal;
                break;
        }
        if (modal) modal.classList.remove('active');
    }
    
    /**
     * Load current settings into the settings modal
     */
    loadSettingsToModal() {
        if (this.elements.settingsNotificationsToggle) {
            this.elements.settingsNotificationsToggle.checked = this.state.notificationsEnabled;
        }
        if (this.elements.settingsSpeedSlider) {
            this.elements.settingsSpeedSlider.value = this.state.currentSpeed;
        }
        if (this.elements.settingsSpeedValue) {
            this.elements.settingsSpeedValue.textContent = `${this.state.currentSpeed.toFixed(1)}x`;
        }
        if (this.elements.defaultMoodSelect) {
            this.elements.defaultMoodSelect.value = this.state.currentMood;
        }
        if (this.elements.autoAdaptToggle) {
            this.elements.autoAdaptToggle.checked = this.state.autoAdaptEnabled;
        }
    }
    
    /**
     * Save settings from modal
     */
    saveSettings() {
        // Get values from modal
        if (this.elements.settingsNotificationsToggle) {
            this.state.notificationsEnabled = this.elements.settingsNotificationsToggle.checked;
        }
        if (this.elements.settingsSpeedSlider) {
            this.state.currentSpeed = parseFloat(this.elements.settingsSpeedSlider.value);
            // Also update the sidebar speed slider if it exists
            if (this.elements.speedSlider) {
                this.elements.speedSlider.value = this.state.currentSpeed;
            }
            if (this.elements.speedValue) {
                this.elements.speedValue.textContent = `${this.state.currentSpeed.toFixed(1)}x`;
            }
        }
        if (this.elements.defaultMoodSelect) {
            this.setMood(this.elements.defaultMoodSelect.value, true);
        }
        if (this.elements.autoAdaptToggle) {
            this.state.autoAdaptEnabled = this.elements.autoAdaptToggle.checked;
        }
        
        // Close modal and show confirmation
        this.closeModal('settings');
        this.showEncouragement('✅ Settings saved!');
        
        console.log('Settings saved:', {
            notifications: this.state.notificationsEnabled,
            speed: this.state.currentSpeed,
            mood: this.state.currentMood,
            autoAdapt: this.state.autoAdaptEnabled
        });
    }

    /**
     * Show loading overlay
     */
    showLoading(message = 'Loading...') {
        this.elements.loadingText.textContent = message;
        this.elements.loadingOverlay.classList.add('active');
    }

    /**
     * Hide loading overlay
     */
    hideLoading() {
        this.elements.loadingOverlay.classList.remove('active');
    }

    /**
     * Handle story generation form submit
     */
    async handleGenerateSubmit(e) {
        e.preventDefault();
        
        const topic = this.elements.storyTopic.value.trim();
        const readingLevel = this.elements.readingLevel.value;
        const length = this.elements.storyLength.value;
        const ageGroup = this.elements.ageGroup.value;
        
        if (!topic) {
            alert('Please enter a topic for your story');
            return;
        }
        
        this.closeModal('generate');
        this.showLoading('✨ Creating your personalized story...');
        
        try {
            const response = await fetch(`${this.config.backendUrl}/api/generate-story`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    topic,
                    readingLevel,
                    length,
                    ageGroup,
                    style: 'engaging'
                })
            });
            
            const data = await response.json();
            
            if (data.success && data.story) {
                this.loadStory(data.story);
            } else {
                throw new Error(data.error || 'Failed to generate story');
            }
        } catch (error) {
            console.error('Generation error:', error);
            alert('Failed to generate story. Please check your connection and try again.');
        } finally {
            this.hideLoading();
        }
    }

    /**
     * Handle story upload form submit
     */
    async handleUploadSubmit(e) {
        e.preventDefault();
        
        const title = this.elements.uploadTitle.value.trim();
        const text = this.elements.uploadText.value.trim();
        
        if (!title || !text) {
            alert('Please enter both a title and text');
            return;
        }
        
        this.closeModal('upload');
        this.showLoading('📖 Processing your text...');
        
        try {
            const response = await fetch(`${this.config.backendUrl}/api/upload-story`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, text })
            });
            
            const data = await response.json();
            
            if (data.success && data.story) {
                this.loadStory(data.story);
            } else {
                throw new Error(data.error || 'Failed to process text');
            }
        } catch (error) {
            console.error('Upload error:', error);
            // Fallback: process locally
            const story = this.parseTextLocally(title, text);
            this.loadStory(story);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * Parse text locally as fallback
     */
    parseTextLocally(title, text) {
        const paragraphs = text
            .split(/\n\n+/)
            .map(p => p.trim())
            .filter(p => p.length > 10);
        
        return {
            title,
            paragraphs: paragraphs.length > 0 ? paragraphs : [text],
            totalParagraphs: paragraphs.length || 1,
            estimatedReadingTime: Math.ceil(text.split(' ').length / 150)
        };
    }

    /**
     * Handle analyze form submit
     */
    async handleAnalyzeSubmit(e) {
        e.preventDefault();
        
        const subject = this.elements.analyzeSubject?.value || 'general';
        const content = this.elements.analyzeContent?.value.trim();
        const level = this.elements.analyzeLevel?.value || 'basic';
        
        if (!content) {
            alert('Please enter content to analyze');
            return;
        }
        
        this.closeModal('analyze');
        this.showLoading('🔍 Analyzing and creating explanation...');
        
        try {
            const response = await fetch(`${this.config.backendUrl}/api/analyze`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    subject,
                    content,
                    level
                })
            });
            
            const data = await response.json();
            
            if (data.success && data.explanation) {
                // Load the explanation as a "story" to read
                this.loadStory(data.explanation);
                this.showEncouragement('🎯 Analysis ready! Press play to hear the explanation.');
            } else {
                throw new Error(data.error || 'Failed to analyze content');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            alert('Failed to analyze content. Please check your connection and try again.');
        } finally {
            this.hideLoading();
        }
    }

    /**
     * Load a story into the reading interface
     */
    loadStory(story) {
        this.state.currentStory = story;
        this.state.currentParagraph = 0;
        this.state.isPaused = true;
        
        // Update UI
        this.elements.storyTitle.textContent = story.title;
        this.elements.paragraphCount.textContent = story.totalParagraphs;
        this.elements.readingTime.textContent = story.estimatedReadingTime;
        
        // Generate progress dots
        this.generateProgressDots();
        
        // Display first paragraph
        this.displayCurrentParagraph();
        
        // Show reading interface
        this.showReadingInterface();
        
        // Notify WebSocket
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'start_reading',
                story: {
                    title: story.title,
                    paragraphCount: story.totalParagraphs
                }
            }));
        }
    }

    /**
     * Generate progress indicator dots
     */
    generateProgressDots() {
        const container = this.elements.readingProgress;
        container.innerHTML = '';
        
        const maxDots = Math.min(this.state.currentStory.totalParagraphs, 20);
        
        for (let i = 0; i < maxDots; i++) {
            const dot = document.createElement('div');
            dot.className = 'progress-dot';
            if (i === 0) dot.classList.add('current');
            container.appendChild(dot);
        }
    }

    /**
     * Update progress dots
     */
    updateProgressDots() {
        const dots = this.elements.readingProgress.querySelectorAll('.progress-dot');
        const current = this.state.currentParagraph;
        
        dots.forEach((dot, i) => {
            dot.classList.remove('current', 'completed');
            if (i < current) {
                dot.classList.add('completed');
            } else if (i === current) {
                dot.classList.add('current');
            }
        });
    }

    /**
     * Display the current paragraph
     */
    displayCurrentParagraph() {
        const paragraph = this.state.currentStory.paragraphs[this.state.currentParagraph];
        
        if (paragraph) {
            this.elements.readingText.textContent = paragraph;
            this.elements.readingText.classList.remove('dimmed');
        }
        
        this.updateProgressDots();
        this.updateControlStates();
    }

    /**
     * Update playback control states
     */
    updateControlStates() {
        const { currentParagraph, currentStory, isPaused } = this.state;
        
        // Previous button
        this.elements.prevBtn.disabled = currentParagraph === 0;
        
        // Next button
        this.elements.nextBtn.disabled = currentParagraph >= currentStory.paragraphs.length - 1;
        
        // Play button icon
        this.elements.playBtn.textContent = isPaused ? '▶️' : '⏸️';
    }

    /**
     * Toggle playback
     */
    togglePlayback() {
        if (this.state.isPaused) {
            this.startReading();
        } else {
            this.pauseReading();
        }
    }

    /**
     * Start reading aloud
     */
    async startReading() {
        this.state.isPaused = false;
        this.state.isReading = true;
        this.updateControlStates();
        
        // Notify WebSocket
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'resume_reading' }));
        }
        
        // Start reading current paragraph
        await this.readCurrentParagraph();
    }

    /**
     * Pause reading
     */
    pauseReading() {
        this.state.isPaused = true;
        this.state.isReading = false;
        this.updateControlStates();
        
        // ACTUALLY stop the current audio
        if (this.state.currentAudio) {
            this.state.currentAudio.pause();
            this.state.currentAudio.currentTime = 0;
            this.state.currentAudio = null;
        }
        
        // Also stop browser TTS if it's playing
        if ('speechSynthesis' in window) {
            speechSynthesis.cancel();
        }
        
        // Notify WebSocket
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'pause_reading' }));
        }
    }

    /**
     * Read the current paragraph using TTS
     */
    async readCurrentParagraph() {
        if (this.state.isPaused) return;
        
        const paragraph = this.state.currentStory.paragraphs[this.state.currentParagraph];
        if (!paragraph) {
            this.pauseReading();
            return;
        }
        
        try {
            // Get audio from backend
            const response = await fetch(`${this.config.backendUrl}/api/text-to-speech`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: paragraph,
                    mood: this.state.currentMood,
                    speed: this.state.currentSpeed
                })
            });
            
            if (!response.ok) {
                throw new Error('TTS request failed');
            }
            
            const audioBlob = await response.blob();
            await this.playAudio(audioBlob);
            
            // If not paused and not at the end, move to next paragraph
            if (!this.state.isPaused && this.state.currentParagraph < this.state.currentStory.paragraphs.length - 1) {
                this.nextParagraph();
                await this.readCurrentParagraph();
            } else if (this.state.currentParagraph >= this.state.currentStory.paragraphs.length - 1) {
                // End of story
                this.pauseReading();
                this.showEncouragement("🎉 Great job! You finished the story!");
            }
            
        } catch (error) {
            console.error('TTS error:', error);
            // Fallback to browser TTS if backend fails
            await this.useBrowserTTS(paragraph);
        }
    }

    /**
     * Play audio blob
     */
    playAudio(blob) {
        return new Promise((resolve, reject) => {
            const audio = new Audio(URL.createObjectURL(blob));
            audio.playbackRate = this.state.currentSpeed;
            
            // Store reference so we can pause it
            this.state.currentAudio = audio;
            
            audio.onended = () => {
                URL.revokeObjectURL(audio.src);
                this.state.currentAudio = null;
                resolve();
            };
            
            audio.onerror = (error) => {
                URL.revokeObjectURL(audio.src);
                this.state.currentAudio = null;
                reject(error);
            };
            
            // Check if we're still supposed to be playing
            if (this.state.isPaused) {
                resolve();
                return;
            }
            
            audio.play().catch(reject);
        });
    }

    /**
     * Fallback browser TTS
     */
    useBrowserTTS(text) {
        return new Promise((resolve) => {
            if (!('speechSynthesis' in window)) {
                resolve();
                return;
            }
            
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = this.state.currentSpeed;
            utterance.onend = resolve;
            utterance.onerror = resolve;
            
            speechSynthesis.speak(utterance);
        });
    }

    /**
     * Go to previous paragraph
     */
    previousParagraph() {
        if (this.state.currentParagraph > 0) {
            this.state.currentParagraph--;
            this.displayCurrentParagraph();
            
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ type: 'prev_paragraph' }));
            }
        }
    }

    /**
     * Go to next paragraph
     */
    nextParagraph() {
        if (this.state.currentParagraph < this.state.currentStory.paragraphs.length - 1) {
            this.state.currentParagraph++;
            this.displayCurrentParagraph();
            
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ type: 'next_paragraph' }));
            }
        }
    }

    /**
     * Set reading mood/voice
     */
    setMood(mood, sendToServer = true) {
        this.state.currentMood = mood;
        
        // Update UI
        this.elements.moodBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mood === mood);
        });
        
        // Update mood indicator
        const moodData = this.getMoodData(mood);
        this.elements.moodIcon.className = `mood-icon ${mood}`;
        this.elements.moodIcon.textContent = moodData.icon;
        this.elements.moodName.textContent = moodData.name;
        this.elements.moodDescription.textContent = moodData.description;
        
        // Notify server
        if (sendToServer && this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'set_mood',
                mood
            }));
        }
    }

    /**
     * Get mood display data
     */
    getMoodData(mood) {
        const moods = {
            calm: { icon: '😌', name: 'Calm', description: 'Steady, reassuring pace' },
            energetic: { icon: '🔥', name: 'Energetic', description: 'Upbeat and lively' },
            soothing: { icon: '🌙', name: 'Soothing', description: 'Gentle and relaxing' },
            expressive: { icon: '🎭', name: 'Expressive', description: 'Dramatic and engaging' },
            encouraging: { icon: '💪', name: 'Encouraging', description: 'Warm and supportive' }
        };
        return moods[mood] || moods.calm;
    }

    /**
     * Show encouragement toast (respects notification setting)
     */
    showEncouragement(message) {
        // Only show if notifications are enabled
        if (!this.state.notificationsEnabled) {
            console.log('Notification (hidden):', message);
            return;
        }
        
        this.elements.encouragementText.textContent = message;
        this.elements.encouragementToast.classList.add('show');
        
        setTimeout(() => {
            this.elements.encouragementToast.classList.remove('show');
        }, 4000);
    }
    
    /**
     * Toggle notifications on/off
     */
    toggleNotifications() {
        this.state.notificationsEnabled = !this.state.notificationsEnabled;
        const status = this.state.notificationsEnabled ? 'enabled' : 'disabled';
        console.log(`Notifications ${status}`);
        
        // Update button if it exists
        if (this.elements.notificationToggle) {
            this.elements.notificationToggle.textContent = this.state.notificationsEnabled ? '🔔' : '🔕';
            this.elements.notificationToggle.title = `Notifications: ${status}`;
        }
        
        // Show feedback
        if (this.state.notificationsEnabled) {
            this.showEncouragement('🔔 Notifications enabled!');
        }
    }

    /**
     * Show welcome screen
     */
    showWelcomeScreen() {
        this.elements.welcomeScreen.style.display = 'flex';
        this.elements.readingInterface.style.display = 'none';
        
        // Reset state
        this.state.currentStory = null;
        this.state.currentParagraph = 0;
        this.state.isPaused = true;
        this.state.isReading = false;
        
        // Stop webcam if active
        if (this.state.webcamActive) {
            this.stopWebcam();
        }
    }

    /**
     * Show reading interface
     */
    showReadingInterface() {
        this.elements.welcomeScreen.style.display = 'none';
        this.elements.readingInterface.style.display = 'grid';
    }
}

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.readFlowApp = new ReadFlowApp();
});
