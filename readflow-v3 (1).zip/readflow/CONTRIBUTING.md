# Contributing to ReadFlow

Thank you for your interest in contributing to ReadFlow! This project aims to help students with reading challenges, and we welcome contributions from everyone.

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in [Issues](../../issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots if applicable
   - Your environment (OS, browser, Node version)

### Suggesting Features

1. Open an issue with the `enhancement` label
2. Describe the feature and why it would be helpful
3. Include mockups or examples if possible

### Pull Requests

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature-name`
3. Make your changes
4. Test thoroughly
5. Commit with clear messages: `git commit -m "Add: description of change"`
6. Push to your fork: `git push origin feature/your-feature-name`
7. Open a Pull Request

### Code Style

- Use meaningful variable and function names
- Add comments for complex logic
- Follow existing code patterns
- Test your changes

### Commit Message Format

```
Type: Short description

Longer description if needed

Fixes #issue_number (if applicable)
```

Types: `Add`, `Fix`, `Update`, `Remove`, `Refactor`, `Docs`

## Development Setup

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/readflow.git
cd readflow

# Install dependencies
cd backend && npm install

# Copy environment template
cp .env.example .env
# Add your API keys to .env

# Start development server
npm run dev
```

## Areas We Need Help With

- 🌍 **Translations** - Multi-language support
- ♿ **Accessibility** - Screen reader improvements
- 📱 **Mobile** - Responsive design enhancements
- 🧪 **Testing** - Unit and integration tests
- 📚 **Documentation** - Tutorials and guides
- 🎨 **Design** - UI/UX improvements

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

## Questions?

Open an issue with the `question` label or reach out to the maintainers.

Thank you for helping make reading easier for students everywhere! 📖✨
