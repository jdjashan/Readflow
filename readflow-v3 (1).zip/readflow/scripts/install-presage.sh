#!/bin/bash
#
# ReadFlow - Presage Technologies C++ SDK Installation Script
# For Ubuntu/Debian-based Linux systems
#
# This script installs the Presage SmartSpectra C++ SDK
# which provides real-time physiological measurement capabilities
#

set -e

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   ReadFlow - Presage SDK Installation                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then
    echo "⚠️  Please run this script with sudo:"
    echo "   sudo ./install-presage.sh"
    exit 1
fi

# Check if running on a supported system
if [ ! -f /etc/debian_version ]; then
    echo "❌ This script is designed for Debian/Ubuntu-based systems."
    echo "   For other systems, please refer to Presage documentation."
    exit 1
fi

echo "📦 Step 1: Adding Presage Technologies PPA..."
echo ""

# Add Presage GPG key
curl -s "https://presage-security.github.io/PPA/KEY.gpg" | gpg --dearmor | tee /etc/apt/trusted.gpg.d/presage-technologies.gpg >/dev/null

# Add Presage repository
curl -s --compressed -o /etc/apt/sources.list.d/presage-technologies.list \
    "https://presage-security.github.io/PPA/presage-technologies.list"

echo "✅ Presage repository added."
echo ""

echo "📦 Step 2: Installing dependencies..."
echo ""

apt update
apt install -y \
    libsmartspectra-dev \
    libopencv-dev \
    libglog-dev \
    cmake \
    ninja-build \
    build-essential

echo "✅ Dependencies installed."
echo ""

echo "📦 Step 3: Creating Presage processor wrapper..."
echo ""

# Create a directory for the Presage wrapper
PRESAGE_DIR="/opt/readflow/presage"
mkdir -p "$PRESAGE_DIR"

# Create a simple C++ wrapper that outputs JSON
cat > "$PRESAGE_DIR/presage_processor.cpp" << 'EOF'
/**
 * ReadFlow Presage Processor
 * 
 * A simple wrapper around the Presage SmartSpectra SDK
 * that outputs physiological metrics as JSON for the Node.js backend
 */

#include <smartspectra/container/foreground_container.hpp>
#include <smartspectra/container/settings.hpp>
#include <physiology/modules/messages/metrics.h>
#include <glog/logging.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <csignal>
#include <atomic>

using namespace presage::smartspectra;

std::atomic<bool> running(true);

void signalHandler(int signum) {
    running = false;
}

std::string toJson(const physiology::modules::messages::Metrics& metrics) {
    std::ostringstream json;
    json << std::fixed << std::setprecision(3);
    json << "{";
    json << "\"heartRate\":" << metrics.pulse_rate << ",";
    json << "\"breathingRate\":" << metrics.breathing_rate << ",";
    json << "\"hrv\":" << metrics.hrv << ",";
    json << "\"confidence\":" << metrics.confidence << ",";
    json << "\"timestamp\":" << std::time(nullptr);
    json << "}";
    return json.str();
}

int main(int argc, char** argv) {
    google::InitGoogleLogging(argv[0]);
    FLAGS_alsologtostderr = false;  // Suppress logs to stderr
    
    // Parse command line arguments
    std::string apiKey;
    int cameraIndex = 0;
    bool continuous = true;
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--api-key" && i + 1 < argc) {
            apiKey = argv[++i];
        } else if (arg == "--camera" && i + 1 < argc) {
            cameraIndex = std::stoi(argv[++i]);
        } else if (arg == "--mode" && i + 1 < argc) {
            continuous = (std::string(argv[++i]) == "continuous");
        }
    }
    
    if (apiKey.empty()) {
        std::cerr << "Error: API key required. Use --api-key YOUR_KEY" << std::endl;
        return 1;
    }
    
    // Set up signal handling for graceful shutdown
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    
    try {
        // Configure settings
        container::settings::Settings<
            container::settings::OperationMode::Continuous,
            container::settings::IntegrationMode::Rest
        > settings;
        
        settings.video_source.device_index = cameraIndex;
        settings.integration.api_key = apiKey;
        settings.headless = true;
        
        // Create container
        container::ForegroundContainer<
            container::settings::ComputeBackend::Cpu,
            container::settings::OperationMode::Continuous
        > container(settings);
        
        // Start processing
        container.start();
        
        // Output metrics as JSON lines
        while (running && container.is_running()) {
            auto metrics = container.get_latest_metrics();
            if (metrics.has_value()) {
                std::cout << toJson(metrics.value()) << std::endl;
                std::cout.flush();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        
        container.stop();
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
EOF

# Create CMakeLists.txt
cat > "$PRESAGE_DIR/CMakeLists.txt" << 'EOF'
cmake_minimum_required(VERSION 3.22)
project(readflow_presage)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(SmartSpectra REQUIRED)
find_package(glog REQUIRED)

add_executable(presage_processor presage_processor.cpp)
target_link_libraries(presage_processor 
    SmartSpectra::Container
    glog::glog
)

install(TARGETS presage_processor DESTINATION bin)
EOF

echo "✅ Wrapper source created."
echo ""

echo "📦 Step 4: Building Presage processor..."
echo ""

cd "$PRESAGE_DIR"
mkdir -p build
cd build
cmake .. -G Ninja
ninja

# Install to /usr/local/bin
cp presage_processor /usr/local/bin/

echo "✅ Presage processor built and installed."
echo ""

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   Installation Complete!                                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "The Presage processor is installed at: /usr/local/bin/presage_processor"
echo ""
echo "To test it, run:"
echo "  presage_processor --api-key YOUR_PRESAGE_API_KEY --camera 0"
echo ""
echo "Get your API key at: https://physiology.presagetech.com/auth/register"
echo ""
echo "Add this to your .env file:"
echo "  PRESAGE_BINARY_PATH=/usr/local/bin/presage_processor"
echo ""
