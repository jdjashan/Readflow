# 📖 ReadFlow - Adaptive AI Reading Companion

<div align="center">

![ReadFlow Logo](https://img.shields.io/badge/ReadFlow-AI%20Reading%20Companion-orange?style=for-the-badge&logo=bookstack)

**An AI-powered reading companion that adapts in real-time to keep students engaged**

[![Node.js](https://img.shields.io/badge/Node.js-18+-green?style=flat-square&logo=node.js)](https://nodejs.org/)
[![License](https://img.shields.io/badge/License-MIT-blue?style=flat-square)](LICENSE)

[Features](#features) • [Architecture](#architecture) • [Installation](#installation) • [Usage](#usage) • [API Keys](#api-keys) • [Deployment](#deployment)

</div>

---

## 🌟 Overview

ReadFlow is an innovative reading companion designed to help students—especially those with dyslexia, ADHD, ESL learners, or anyone struggling with motivation—stay engaged while reading. It uses cutting-edge AI technologies to:

- **Monitor engagement** through webcam-based physiological sensing (Presage Technologies)
- **Adapt the reading voice** in real-time based on detected emotions (ElevenLabs)
- **Generate personalized stories** and orchestrate the experience (Google Gemini)

## ✨ Features

### 🎧 Adaptive Text-to-Speech
- **5 Voice Moods**: Calm, Energetic, Soothing, Expressive, Encouraging
- **Real-time Adaptation**: Voice automatically adjusts based on engagement
- **Speed Control**: 0.5x to 1.5x reading speed
- **High-Quality Voices**: Powered by ElevenLabs' neural TTS

### 👁️ Engagement Detection
- **Focus Monitoring**: Detects when attention wanders
- **Fatigue Detection**: Recognizes tiredness and adjusts accordingly
- **Stress Analysis**: Identifies stress and switches to calming voices
- **Privacy-First**: All processing is anonymized; no personal data stored

### 🤖 AI Story Generation
- **Custom Topics**: Generate stories about any subject
- **Reading Levels**: Beginner, Intermediate, Advanced
- **Age Groups**: Children (6-10) to Adults
- **Multiple Lengths**: Short, Medium, Long stories

### 📱 Modern Web Interface
- **Beautiful Dark Theme**: Warm, inviting design optimized for reading
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Accessibility**: High contrast, keyboard navigation, screen reader support
- **Progress Tracking**: Visual progress indicators

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend (Browser)                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   Webcam    │  │   Reading   │  │    Engagement Panel     │  │
│  │   Capture   │  │   Display   │  │   (Metrics & Controls)  │  │
│  └──────┬──────┘  └──────┬──────┘  └────────────┬────────────┘  │
│         │                │                      │                │
│         └────────────────┼──────────────────────┘                │
│                          │                                       │
│                    WebSocket + REST API                          │
└──────────────────────────┼───────────────────────────────────────┘
                           │
┌──────────────────────────┼───────────────────────────────────────┐
│                     Backend Server (Node.js)                      │
│  ┌─────────────────┐  ┌──────────────┐  ┌─────────────────────┐  │
│  │  Session Mgmt   │  │  Adaptation  │  │    API Handlers     │  │
│  │  & WebSockets   │  │    Engine    │  │  (REST endpoints)   │  │
│  └────────┬────────┘  └──────┬───────┘  └──────────┬──────────┘  │
│           │                  │                     │              │
│           └──────────────────┼─────────────────────┘              │
└──────────────────────────────┼────────────────────────────────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
         ▼                     ▼                     ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│    Presage      │  │   ElevenLabs   │  │  Google Gemini  │
│  Technologies   │  │      TTS       │  │       AI        │
│  (Engagement)   │  │    (Voice)     │  │   (Stories)     │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

---

## 🚀 Installation

### Prerequisites

- **Node.js 18+** - [Download](https://nodejs.org/)
- **npm** or **yarn**
- **Modern browser** with webcam support

### Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/readflow.git
   cd readflow
   ```

2. **Install backend dependencies**
   ```bash
   cd backend
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

4. **Start the backend server**
   ```bash
   npm start
   ```

5. **Serve the frontend**
   ```bash
   cd ../frontend
   # Using Python
   python -m http.server 3000
   # Or using Node
   npx serve -p 3000
   ```

6. **Open in browser**
   ```
   http://localhost:3000
   ```

---

## 🔑 API Keys

ReadFlow requires API keys from three services:

### 1. Presage Technologies (Engagement Detection)
- **Get your key**: https://physiology.presagetech.com/auth/register
- **Pricing**: Starts at $0.007 per measurement
- **Note**: For demo/development, the app works with simulated data if no key is provided

### 2. ElevenLabs (Text-to-Speech)
- **Get your key**: https://elevenlabs.io → Profile Settings
- **Pricing**: Free tier available (10,000 characters/month)
- **Fallback**: Browser's built-in TTS if not configured

### 3. Google Gemini (Story Generation)
- **Get your key**: https://aistudio.google.com/app/apikey
- **Pricing**: Free tier available
- **Note**: Story generation won't work without this key

### Environment Variables

Create a `.env` file in the `backend` directory:

```env
# Server
PORT=3001

# Presage Technologies
PRESAGE_API_KEY=your_presage_key_here

# ElevenLabs
ELEVENLABS_API_KEY=your_elevenlabs_key_here

# Google Gemini
GEMINI_API_KEY=your_gemini_key_here
```

---

## 🖥️ Usage

### Starting a Reading Session

1. **Launch the app** and click "Generate a Story" or "Upload Text"
2. **For generated stories**: Enter a topic, select reading level, and click Generate
3. **For uploaded text**: Paste your text and give it a title
4. **Enable webcam** (optional) for engagement detection
5. **Press Play** to start the adaptive reading experience

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Space` | Play/Pause |
| `←` | Previous paragraph |
| `→` | Next paragraph |

### Voice Moods

| Mood | Icon | Best For |
|------|------|----------|
| Calm | 😌 | Default reading, focused sessions |
| Energetic | 🔥 | Recapturing attention, exciting scenes |
| Soothing | 🌙 | Fatigue, bedtime reading |
| Expressive | 🎭 | High engagement, dramatic passages |
| Encouraging | 💪 | Difficult content, low confidence |

---

## 🐳 Deployment

### Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

### Manual Production Deployment

1. **Backend** (Node.js server)
   ```bash
   cd backend
   NODE_ENV=production npm start
   ```

2. **Frontend** (Static files)
   - Serve with nginx, Apache, or any static file server
   - Configure reverse proxy to backend at `/api/*`

### Installing Presage C++ SDK (Optional)

For real-time engagement detection on Linux servers:

```bash
sudo ./scripts/install-presage.sh
```

This installs the native Presage SmartSpectra SDK for optimal performance.

---

## 📁 Project Structure

```
readflow/
├── backend/
│   ├── server.js           # Main Express/WebSocket server
│   ├── package.json        # Node dependencies
│   ├── Dockerfile          # Container configuration
│   └── .env.example        # Environment template
├── frontend/
│   ├── index.html          # Main HTML file
│   └── app.js              # Client-side JavaScript
├── scripts/
│   └── install-presage.sh  # Presage SDK installer
├── docker-compose.yml      # Docker orchestration
├── nginx.conf              # Nginx configuration
└── README.md               # This file
```

---

## 🎯 Target Users

- **Students with Dyslexia**: Adaptive pacing and voice help with reading challenges
- **Students with ADHD**: Engagement detection keeps sessions productive
- **ESL Learners**: Speed control and clear voices aid comprehension
- **Reluctant Readers**: AI-generated stories on topics of interest boost motivation
- **Parents & Teachers**: Monitor engagement and track reading progress

---

## 🔮 Future Enhancements

- [ ] Multi-language support
- [ ] Reading comprehension quizzes
- [ ] Progress analytics dashboard
- [ ] Mobile app (React Native)
- [ ] Classroom/group reading mode
- [ ] Integration with e-book formats (EPUB, PDF)
- [ ] Custom voice cloning
- [ ] Vocabulary highlighting and definitions

---

## 🤝 Contributing

Contributions are welcome! Please read our contributing guidelines before submitting PRs.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- **Presage Technologies** - Real-time physiological sensing
- **ElevenLabs** - Neural text-to-speech
- **Google Gemini** - AI story generation
- **The open-source community** - For the amazing tools that made this possible

---

<div align="center">

**Made with ❤️ for students everywhere**

[Report Bug](../../issues) • [Request Feature](../../issues) • [Documentation](../../wiki)

</div>
