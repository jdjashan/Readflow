/**
 * ReadFlow Backend Server
 * 
 * A Node.js server that bridges:
 * - Presage Technologies (engagement/emotion detection via C++ SDK or REST API)
 * - ElevenLabs (adaptive text-to-speech)
 * - Google Gemini (story generation and AI orchestration)
 * 
 * Architecture:
 * - Express.js for REST API
 * - WebSocket for real-time video frame streaming
 * - Child process spawning for Presage C++ SDK integration
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const multer = require('multer');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

// Load environment variables
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Configuration
const CONFIG = {
    port: process.env.PORT || 3001,
    presageApiKey: process.env.PRESAGE_API_KEY || '',
    elevenLabsApiKey: process.env.ELEVENLABS_API_KEY || '',
    geminiApiKey: process.env.GEMINI_API_KEY || '',
    
    // ElevenLabs voice configurations - NATURAL HUMAN-LIKE VOICES
    // Using eleven_turbo_v2_5 model for best quality + speed balance
    // Lower stability = more natural/expressive, higher style = more emotional
    // These settings are tuned for maximum expressiveness and natural delivery
    voices: {
        calm: {
            voiceId: 'EXAVITQu4vr4xnSDxMaL',  // Sarah - soft, calm, warm female
            stability: 0.30,         // Lower = more natural variation & emotion
            similarityBoost: 0.65,   // Lower = more creative interpretation
            style: 0.35,             // Moderate expressiveness
            speakingRate: 0.95
        },
        energetic: {
            voiceId: '9BWtsMINqrJLrRacOk9x', // Aria - expressive, engaging female
            stability: 0.20,         // Very low = lots of natural variation
            similarityBoost: 0.60,
            style: 0.85,             // High expressiveness for energy
            speakingRate: 1.05
        },
        soothing: {
            voiceId: 'XB0fDUnXU5powFXDhCwa', // Charlotte - gentle, soothing female
            stability: 0.35,         // Slightly more steady but still natural
            similarityBoost: 0.70,
            style: 0.25,             // Calm, gentle delivery
            speakingRate: 0.85
        },
        expressive: {
            voiceId: 'cgSgspJ2msm6clMCkdW9', // Jessica - youthful, expressive female
            stability: 0.15,         // Very natural/variable - like a real storyteller
            similarityBoost: 0.55,
            style: 0.95,             // Maximum drama/expression for storytelling
            speakingRate: 1.0
        },
        encouraging: {
            voiceId: 'cjVigY5qzO86Huf0OWal', // Eric - friendly, warm, approachable male
            stability: 0.25,
            similarityBoost: 0.65,
            style: 0.60,             // Warm and supportive, uplifting
            speakingRate: 0.95
        }
    },
    
    // Engagement thresholds for adaptive reading (more sensitive)
    thresholds: {
        focusLoss: 0.45,     // Below this = lost focus
        fatigue: 0.35,       // Above this = fatigued
        confusion: 0.55,     // Below this = confused
        stress: 0.45,        // Above this = stressed
        engagement: 0.65     // Above this = highly engaged
    }
};

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// File upload configuration
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Store active sessions
const sessions = new Map();

/**
 * Session class to manage reading sessions
 */
class ReadingSession {
    constructor(sessionId, ws) {
        this.sessionId = sessionId;
        this.ws = ws;
        this.story = null;
        this.currentParagraph = 0;
        this.isReading = false;
        this.currentMood = 'calm';
        this.engagementHistory = [];
        this.lastEmotionData = null;
        this.adaptiveSettings = {
            speed: 1.0,
            voice: 'calm',
            expressiveness: 0.5
        };
    }
    
    updateEngagement(data) {
        this.lastEmotionData = data;
        this.engagementHistory.push({
            timestamp: Date.now(),
            ...data
        });
        
        // Keep only last 30 seconds of data
        const cutoff = Date.now() - 30000;
        this.engagementHistory = this.engagementHistory.filter(d => d.timestamp > cutoff);
        
        // Analyze and adapt
        this.analyzeAndAdapt();
    }
    
    analyzeAndAdapt() {
        if (this.engagementHistory.length < 3) return;
        
        // Calculate averages
        const recent = this.engagementHistory.slice(-10);
        const avgFocus = recent.reduce((sum, d) => sum + (d.focus || 0.5), 0) / recent.length;
        const avgStress = recent.reduce((sum, d) => sum + (d.stress || 0.3), 0) / recent.length;
        const avgEngagement = recent.reduce((sum, d) => sum + (d.engagement || 0.5), 0) / recent.length;
        const avgFatigue = recent.reduce((sum, d) => sum + (d.fatigue || 0.3), 0) / recent.length;
        
        let newMood = this.currentMood;
        let newSpeed = this.adaptiveSettings.speed;
        let recommendation = '';
        
        // Decision logic for adaptive reading
        if (avgFocus < CONFIG.thresholds.focusLoss) {
            newMood = 'energetic';
            newSpeed = 1.1;
            recommendation = 'Increasing energy to recapture attention';
        } else if (avgFatigue > 0.6) {
            newMood = 'soothing';
            newSpeed = 0.85;
            recommendation = 'Slowing down - detected fatigue';
        } else if (avgStress > CONFIG.thresholds.stress) {
            newMood = 'soothing';
            newSpeed = 0.9;
            recommendation = 'Switching to calming voice - stress detected';
        } else if (avgEngagement < CONFIG.thresholds.confusion) {
            newMood = 'encouraging';
            newSpeed = 0.9;
            recommendation = 'Adding encouragement - engagement dropping';
        } else if (avgEngagement > CONFIG.thresholds.engagement) {
            newMood = 'expressive';
            newSpeed = 1.0;
            recommendation = 'Great engagement! Adding expressiveness';
        } else {
            newMood = 'calm';
            newSpeed = 1.0;
            recommendation = 'Maintaining steady pace';
        }
        
        // Only update if there's a change
        if (newMood !== this.currentMood || Math.abs(newSpeed - this.adaptiveSettings.speed) > 0.05) {
            this.currentMood = newMood;
            this.adaptiveSettings.speed = newSpeed;
            this.adaptiveSettings.voice = newMood;
            
            // Notify client of adaptation
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                    type: 'adaptation',
                    mood: newMood,
                    speed: newSpeed,
                    recommendation,
                    metrics: {
                        focus: avgFocus,
                        stress: avgStress,
                        engagement: avgEngagement,
                        fatigue: avgFatigue
                    }
                }));
            }
        }
    }
}

// ============================================
// REST API ENDPOINTS
// ============================================

/**
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        services: {
            presage: !!CONFIG.presageApiKey,
            elevenLabs: !!CONFIG.elevenLabsApiKey,
            gemini: !!CONFIG.geminiApiKey
        }
    });
});

/**
 * Generate a story using Gemini AI
 */
app.post('/api/generate-story', async (req, res) => {
    try {
        const { 
            topic, 
            readingLevel = 'intermediate', 
            length = 'medium',
            style = 'engaging',
            ageGroup = 'children'
        } = req.body;
        
        if (!CONFIG.geminiApiKey) {
            console.error('❌ Gemini API key not configured');
            return res.status(400).json({ error: 'Gemini API key not configured. Add GEMINI_API_KEY to your .env file.' });
        }
        
        console.log('📖 Generating story about:', topic);
        console.log('   Settings:', { readingLevel, length, ageGroup });
        
        const prompt = buildStoryPrompt(topic, readingLevel, length, style, ageGroup);
        
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${CONFIG.geminiApiKey}`;
        
        console.log('🔗 Calling Gemini API...');
        
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: {
                    temperature: 0.8,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 4096
                }
            })
        });
        
        const data = await response.json();
        
        // Check for API errors
        if (!response.ok) {
            console.error('❌ Gemini API error:', response.status, data);
            return res.status(response.status).json({ 
                error: 'Gemini API error', 
                details: data.error?.message || JSON.stringify(data)
            });
        }
        
        if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
            const storyText = data.candidates[0].content.parts[0].text;
            const story = parseStoryResponse(storyText);
            
            console.log('✅ Story generated:', story.title, `(${story.totalParagraphs} paragraphs)`);
            
            res.json({
                success: true,
                story
            });
        } else {
            console.error('❌ Unexpected Gemini response format:', JSON.stringify(data, null, 2));
            throw new Error('Invalid response format from Gemini');
        }
    } catch (error) {
        console.error('❌ Story generation error:', error.message);
        console.error('   Stack:', error.stack);
        res.status(500).json({ error: 'Failed to generate story', details: error.message });
    }
});

/**
 * Upload a story/document for reading
 */
app.post('/api/upload-story', upload.single('file'), async (req, res) => {
    try {
        let content = '';
        
        if (req.file) {
            // Handle file upload
            content = req.file.buffer.toString('utf-8');
        } else if (req.body.text) {
            // Handle direct text input
            content = req.body.text;
        } else {
            return res.status(400).json({ error: 'No content provided' });
        }
        
        const story = parseTextToStory(content, req.body.title || 'Uploaded Story');
        
        res.json({
            success: true,
            story
        });
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ error: 'Failed to process upload' });
    }
});

/**
 * Analyze content and create an explanation using Gemini
 */
app.post('/api/analyze', async (req, res) => {
    try {
        const { subject = 'general', content, level = 'basic' } = req.body;
        
        if (!CONFIG.geminiApiKey) {
            return res.status(400).json({ error: 'Gemini API key not configured' });
        }
        
        if (!content || content.trim().length === 0) {
            return res.status(400).json({ error: 'No content provided to analyze' });
        }
        
        console.log(`🔍 Analyzing ${subject} content at ${level} level...`);
        
        const prompt = buildAnalysisPrompt(subject, content, level);
        
        const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${CONFIG.geminiApiKey}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 4096
                    }
                })
            }
        );
        
        const data = await response.json();
        
        if (!response.ok) {
            console.error('❌ Gemini API error:', response.status, data);
            throw new Error(data.error?.message || 'Gemini API error');
        }
        
        if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
            const explanationText = data.candidates[0].content.parts[0].text;
            const explanation = parseExplanationResponse(explanationText, subject);
            
            console.log('✅ Analysis complete:', explanation.title, `(${explanation.totalParagraphs} paragraphs)`);
            
            res.json({
                success: true,
                explanation
            });
        } else {
            throw new Error('Invalid response from Gemini');
        }
    } catch (error) {
        console.error('❌ Analysis error:', error.message);
        res.status(500).json({ error: 'Failed to analyze content', details: error.message });
    }
});

/**
 * Build analysis prompt for Gemini
 */
function buildAnalysisPrompt(subject, content, level) {
    const levelDescriptions = {
        simple: 'Explain this like you\'re talking to an 8-year-old child. Use very simple words, fun comparisons, and short sentences. Be warm and encouraging.',
        basic: 'Explain this at a middle school level. Use clear language, helpful examples, and break down complex ideas step by step.',
        detailed: 'Explain this at a high school level. Include relevant details, explain the reasoning, and provide context.',
        advanced: 'Explain this at a college level. Be thorough, precise, and include deeper insights and connections.'
    };
    
    const subjectHints = {
        general: 'Analyze and explain the following content clearly.',
        math: 'Explain this mathematical concept or solve this problem step by step. Show your work and explain WHY each step is done, not just how.',
        science: 'Explain this scientific concept. Include how it works, why it matters, and real-world examples if possible.',
        english: 'Analyze this text. Discuss its meaning, themes, literary devices, and significance. Help the reader truly understand it.',
        history: 'Explain this historical topic. Include context, key events, important figures, and why it matters today.'
    };
    
    return `You are a patient, engaging tutor helping a student understand something. Your goal is to make learning enjoyable and the explanation crystal clear.

${subjectHints[subject] || subjectHints.general}

${levelDescriptions[level] || levelDescriptions.basic}

IMPORTANT: Structure your response for reading aloud:
- Start with a brief, engaging introduction
- Break the explanation into clear sections (use numbered paragraphs)
- Use a conversational, warm tone - like you're talking TO the student
- Include encouraging phrases like "Great question!", "Here's the cool part...", "You're doing great following along!"
- End with a quick summary and encouragement

Content to analyze and explain:
"""
${content}
"""

Provide your explanation now, numbered by paragraph (1., 2., 3., etc.):`;
}

/**
 * Parse the explanation response into a readable format
 */
function parseExplanationResponse(text, subject) {
    // Clean up the response
    let cleanText = text.trim();
    
    // Extract title or create one
    let title = `${getSubjectEmoji(subject)} Explanation`;
    const titleMatch = cleanText.match(/^#?\s*(.+?)[\n\r]/);
    if (titleMatch) {
        title = titleMatch[1].replace(/^[#*]+\s*/, '').trim();
        cleanText = cleanText.substring(titleMatch[0].length);
    }
    
    // Split into paragraphs
    const paragraphs = cleanText
        .split(/\n\s*\d+\.\s*|\n\n+/)
        .map(p => p.replace(/^\d+\.\s*/, '').trim())
        .filter(p => p.length > 20);
    
    // If no good splits, do it by sentences
    if (paragraphs.length < 2) {
        const sentences = cleanText.split(/(?<=[.!?])\s+/);
        const chunks = [];
        let currentChunk = '';
        
        for (const sentence of sentences) {
            if (currentChunk.length + sentence.length > 300 && currentChunk.length > 100) {
                chunks.push(currentChunk.trim());
                currentChunk = sentence;
            } else {
                currentChunk += ' ' + sentence;
            }
        }
        if (currentChunk.trim()) chunks.push(currentChunk.trim());
        
        return {
            title,
            paragraphs: chunks,
            totalParagraphs: chunks.length,
            estimatedReadingTime: Math.ceil(cleanText.split(' ').length / 150),
            isAnalysis: true
        };
    }
    
    return {
        title,
        paragraphs,
        totalParagraphs: paragraphs.length,
        estimatedReadingTime: Math.ceil(cleanText.split(' ').length / 150),
        isAnalysis: true
    };
}

/**
 * Get emoji for subject
 */
function getSubjectEmoji(subject) {
    const emojis = {
        general: '📝',
        math: '🧮',
        science: '🔬',
        english: '📖',
        history: '🏛️'
    };
    return emojis[subject] || '📝';
}

/**
 * Preprocess text for more natural speech
 * Adds subtle cues that help ElevenLabs deliver more human-like reading
 */
function preprocessTextForSpeech(text, mood) {
    let processed = text;
    
    // Add natural pauses after punctuation (ElevenLabs respects these)
    processed = processed.replace(/\. /g, '... ');  // Longer pause after periods
    processed = processed.replace(/! /g, '!.. ');   // Pause after exclamations
    processed = processed.replace(/\? /g, '?.. ');  // Pause after questions
    processed = processed.replace(/; /g, ';.. ');   // Medium pause after semicolons
    processed = processed.replace(/: /g, ':.. ');   // Medium pause after colons
    
    // Handle ellipsis for dramatic effect
    processed = processed.replace(/\.\.\./g, '... ... ');  // Longer pause for ellipsis
    
    // Add breathing room for long sentences in calmer moods
    if (mood === 'soothing' || mood === 'calm') {
        processed = processed.replace(/ and /g, ', and ');
        processed = processed.replace(/ but /g, ', but ');
    }
    
    return processed;
}

/**
 * Convert text to speech using ElevenLabs
 */
app.post('/api/text-to-speech', async (req, res) => {
    try {
        const { text, mood = 'calm', speed = 1.0 } = req.body;
        
        if (!CONFIG.elevenLabsApiKey) {
            return res.status(400).json({ error: 'ElevenLabs API key not configured' });
        }
        
        if (!text || text.trim().length === 0) {
            return res.status(400).json({ error: 'No text provided' });
        }
        
        // Preprocess text for more natural delivery
        const processedText = preprocessTextForSpeech(text, mood);
        
        const voiceConfig = CONFIG.voices[mood] || CONFIG.voices.calm;
        
        console.log(`🎤 TTS: "${processedText.substring(0, 50)}..." [${mood}]`);
        
        const response = await fetch(
            `https://api.elevenlabs.io/v1/text-to-speech/${voiceConfig.voiceId}`,
            {
                method: 'POST',
                headers: {
                    'Accept': 'audio/mpeg',
                    'Content-Type': 'application/json',
                    'xi-api-key': CONFIG.elevenLabsApiKey
                },
                body: JSON.stringify({
                    text: processedText,
                    model_id: 'eleven_turbo_v2_5',  // Much more natural sounding!
                    voice_settings: {
                        stability: voiceConfig.stability,
                        similarity_boost: voiceConfig.similarityBoost,
                        style: voiceConfig.style,
                        use_speaker_boost: true
                    }
                })
            }
        );
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`ElevenLabs API error: ${errorText}`);
        }
        
        const audioBuffer = await response.arrayBuffer();
        
        res.set({
            'Content-Type': 'audio/mpeg',
            'Content-Length': audioBuffer.byteLength
        });
        
        res.send(Buffer.from(audioBuffer));
    } catch (error) {
        console.error('TTS error:', error);
        res.status(500).json({ error: 'Failed to generate speech', details: error.message });
    }
});

/**
 * Get available voices
 */
app.get('/api/voices', (req, res) => {
    res.json({
        voices: Object.keys(CONFIG.voices).map(key => ({
            id: key,
            name: key.charAt(0).toUpperCase() + key.slice(1),
            description: getVoiceDescription(key)
        }))
    });
});

/**
 * Process video frame through Presage (REST API fallback)
 * This endpoint is for when the C++ SDK is not available
 */
app.post('/api/analyze-frame', async (req, res) => {
    try {
        const { frameData, sessionId } = req.body;
        
        // If Presage API key is available, use REST API
        if (CONFIG.presageApiKey) {
            // For real implementation, you would send to Presage REST API
            // For now, we'll use simulated engagement data
            const analysisResult = await analyzeWithPresage(frameData);
            res.json(analysisResult);
        } else {
            // Fallback to simulated data for demo
            const simulatedResult = generateSimulatedEngagement();
            res.json(simulatedResult);
        }
    } catch (error) {
        console.error('Frame analysis error:', error);
        res.status(500).json({ error: 'Failed to analyze frame' });
    }
});

/**
 * Gemini-powered engagement analysis and recommendations
 */
app.post('/api/analyze-engagement', async (req, res) => {
    try {
        const { engagementData, currentParagraph, storyContext } = req.body;
        
        if (!CONFIG.geminiApiKey) {
            return res.json({ recommendation: 'Continue reading at current pace' });
        }
        
        const prompt = `You are an AI reading companion helping a student stay engaged. 
        
Current engagement metrics:
- Focus level: ${engagementData.focus}
- Stress level: ${engagementData.stress}  
- Fatigue level: ${engagementData.fatigue}
- Overall engagement: ${engagementData.engagement}

Current story context: "${storyContext}"

Based on these metrics, provide a brief JSON response with:
1. "voiceMood": one of [calm, energetic, soothing, expressive, encouraging]
2. "speedAdjustment": a number between 0.7 and 1.3
3. "shouldPause": boolean
4. "encouragement": a short encouraging phrase to display (if engagement is low)
5. "recommendation": brief explanation

Respond ONLY with valid JSON.`;

        const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${CONFIG.geminiApiKey}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: {
                        temperature: 0.3,
                        maxOutputTokens: 500
                    }
                })
            }
        );
        
        const data = await response.json();
        
        if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
            let jsonText = data.candidates[0].content.parts[0].text;
            // Clean up the response
            jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
            const analysis = JSON.parse(jsonText);
            res.json(analysis);
        } else {
            res.json({ recommendation: 'Continue reading' });
        }
    } catch (error) {
        console.error('Engagement analysis error:', error);
        res.json({ recommendation: 'Continue reading at current pace' });
    }
});

// ============================================
// WEBSOCKET HANDLING
// ============================================

wss.on('connection', (ws, req) => {
    const sessionId = generateSessionId();
    const session = new ReadingSession(sessionId, ws);
    sessions.set(sessionId, session);
    
    console.log(`New session connected: ${sessionId}`);
    
    ws.send(JSON.stringify({
        type: 'connected',
        sessionId
    }));
    
    ws.on('message', async (message) => {
        try {
            const data = JSON.parse(message);
            
            switch (data.type) {
                case 'video_frame':
                    await handleVideoFrame(session, data);
                    break;
                    
                case 'start_reading':
                    session.story = data.story;
                    session.currentParagraph = 0;
                    session.isReading = true;
                    break;
                    
                case 'pause_reading':
                    session.isReading = false;
                    break;
                    
                case 'resume_reading':
                    session.isReading = true;
                    break;
                    
                case 'next_paragraph':
                    session.currentParagraph++;
                    break;
                    
                case 'set_mood':
                    session.currentMood = data.mood;
                    break;
                    
                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong' }));
                    break;
            }
        } catch (error) {
            console.error('WebSocket message error:', error);
        }
    });
    
    ws.on('close', () => {
        console.log(`Session disconnected: ${sessionId}`);
        sessions.delete(sessionId);
    });
    
    ws.on('error', (error) => {
        console.error(`WebSocket error for session ${sessionId}:`, error);
    });
});

/**
 * Handle incoming video frames for engagement analysis
 */
async function handleVideoFrame(session, data) {
    try {
        let engagementData;
        
        if (CONFIG.presageApiKey) {
            // Use Presage for real analysis
            engagementData = await analyzeWithPresage(data.frame);
        } else {
            // Simulated engagement for demo
            engagementData = generateSimulatedEngagement(session.lastEmotionData);
        }
        
        // Update session with new engagement data
        session.updateEngagement(engagementData);
        
        // Send engagement data back to client
        if (session.ws && session.ws.readyState === WebSocket.OPEN) {
            session.ws.send(JSON.stringify({
                type: 'engagement_update',
                data: engagementData,
                adaptiveSettings: session.adaptiveSettings
            }));
        }
    } catch (error) {
        console.error('Video frame handling error:', error);
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function buildStoryPrompt(topic, readingLevel, length, style, ageGroup) {
    const lengthGuide = {
        short: '300-500 words, 3-4 paragraphs',
        medium: '600-900 words, 5-7 paragraphs',
        long: '1000-1500 words, 8-12 paragraphs'
    };
    
    const levelGuide = {
        beginner: 'simple sentences, common words, short paragraphs',
        intermediate: 'varied sentence structure, grade-appropriate vocabulary',
        advanced: 'complex sentences, rich vocabulary, nuanced themes'
    };
    
    return `Create an engaging story for ${ageGroup} readers about: ${topic}

Requirements:
- Reading level: ${readingLevel} (${levelGuide[readingLevel] || levelGuide.intermediate})
- Length: ${length} (${lengthGuide[length] || lengthGuide.medium})
- Style: ${style}, with moments of excitement and calm
- Include descriptive language that helps visualization
- Add natural pauses and emotional beats for read-aloud performance
- Make it educational but entertaining

Format your response as:
TITLE: [Story Title]

PARAGRAPH 1:
[First paragraph text]

PARAGRAPH 2:
[Second paragraph text]

(Continue with numbered paragraphs)

THE END`;
}

function parseStoryResponse(text) {
    const lines = text.split('\n').filter(line => line.trim());
    let title = 'Untitled Story';
    const paragraphs = [];
    let currentParagraph = '';
    
    for (const line of lines) {
        if (line.startsWith('TITLE:')) {
            title = line.replace('TITLE:', '').trim();
        } else if (line.match(/^PARAGRAPH \d+:/i)) {
            if (currentParagraph.trim()) {
                paragraphs.push(currentParagraph.trim());
            }
            currentParagraph = '';
        } else if (line.trim() === 'THE END') {
            if (currentParagraph.trim()) {
                paragraphs.push(currentParagraph.trim());
            }
            paragraphs.push('The End.');
        } else {
            currentParagraph += ' ' + line;
        }
    }
    
    if (currentParagraph.trim() && !paragraphs.includes(currentParagraph.trim())) {
        paragraphs.push(currentParagraph.trim());
    }
    
    return {
        title,
        paragraphs: paragraphs.filter(p => p.length > 0),
        totalParagraphs: paragraphs.length,
        estimatedReadingTime: Math.ceil(paragraphs.join(' ').split(' ').length / 150) // ~150 words per minute
    };
}

function parseTextToStory(text, title) {
    // Split by double newlines or paragraph markers
    const paragraphs = text
        .split(/\n\n+/)
        .map(p => p.trim())
        .filter(p => p.length > 20); // Filter out very short fragments
    
    return {
        title,
        paragraphs,
        totalParagraphs: paragraphs.length,
        estimatedReadingTime: Math.ceil(text.split(' ').length / 150)
    };
}

function generateSessionId() {
    return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function getVoiceDescription(voiceKey) {
    const descriptions = {
        calm: 'Steady and reassuring, perfect for focused reading',
        energetic: 'Upbeat and lively, great for recapturing attention',
        soothing: 'Gentle and relaxing, ideal when fatigue is detected',
        expressive: 'Dramatic and engaging, for high-engagement moments',
        encouraging: 'Warm and supportive, helps with difficult passages'
    };
    return descriptions[voiceKey] || 'A helpful reading voice';
}

/**
 * Analyze video with Presage Technologies REST API
 */
async function analyzeWithPresage(frameData) {
    // In production, this would:
    // 1. Convert frame data to video format
    // 2. Send to Presage REST API
    // 3. Parse the response for physiological metrics
    
    // For now, return simulated data since we need the full SDK setup
    return generateSimulatedEngagement();
}

/**
 * Generate simulated engagement data for demo/testing
 * Creates more dramatic swings to demonstrate adaptation
 */
let simulationCycle = 0;
function generateSimulatedEngagement(previousData = null) {
    simulationCycle++;
    
    // Create cyclical patterns that will trigger different moods
    const cyclePosition = (simulationCycle % 60); // 60-step cycle
    
    let focus, stress, fatigue, engagement;
    
    if (cyclePosition < 15) {
        // Phase 1: Good engagement (calm voice)
        focus = 0.7 + Math.random() * 0.15;
        stress = 0.2 + Math.random() * 0.1;
        fatigue = 0.15 + Math.random() * 0.1;
        engagement = 0.75 + Math.random() * 0.15;
    } else if (cyclePosition < 25) {
        // Phase 2: Losing focus (switch to energetic)
        focus = 0.25 + Math.random() * 0.15;
        stress = 0.3 + Math.random() * 0.15;
        fatigue = 0.3 + Math.random() * 0.1;
        engagement = 0.4 + Math.random() * 0.15;
    } else if (cyclePosition < 35) {
        // Phase 3: Getting stressed (switch to soothing)
        focus = 0.5 + Math.random() * 0.1;
        stress = 0.6 + Math.random() * 0.2;
        fatigue = 0.35 + Math.random() * 0.1;
        engagement = 0.45 + Math.random() * 0.15;
    } else if (cyclePosition < 45) {
        // Phase 4: Fatigued (switch to soothing)
        focus = 0.45 + Math.random() * 0.1;
        stress = 0.25 + Math.random() * 0.1;
        fatigue = 0.6 + Math.random() * 0.2;
        engagement = 0.4 + Math.random() * 0.15;
    } else if (cyclePosition < 55) {
        // Phase 5: Highly engaged! (switch to expressive)
        focus = 0.8 + Math.random() * 0.15;
        stress = 0.15 + Math.random() * 0.1;
        fatigue = 0.1 + Math.random() * 0.1;
        engagement = 0.85 + Math.random() * 0.1;
    } else {
        // Phase 6: Engagement dropping (switch to encouraging)
        focus = 0.5 + Math.random() * 0.1;
        stress = 0.3 + Math.random() * 0.1;
        fatigue = 0.25 + Math.random() * 0.1;
        engagement = 0.35 + Math.random() * 0.1;
    }
    
    return {
        focus: Math.max(0, Math.min(1, focus)),
        stress: Math.max(0, Math.min(1, stress)),
        fatigue: Math.max(0, Math.min(1, fatigue)),
        engagement: Math.max(0, Math.min(1, engagement)),
        heartRate: Math.round(68 + Math.random() * 15),
        breathingRate: Math.round(12 + Math.random() * 6),
        blinkRate: Math.round(15 + Math.random() * 10),
        timestamp: Date.now(),
        confidence: 0.85 + Math.random() * 0.1
    };
}

// ============================================
// PRESAGE C++ SDK INTEGRATION (Optional)
// ============================================

/**
 * Spawn Presage C++ process for real-time analysis
 * This is used when the C++ SDK is installed on the server
 */
class PresageProcessor {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.process = null;
        this.callbacks = new Map();
    }
    
    start() {
        // Path to compiled Presage binary
        const binaryPath = process.env.PRESAGE_BINARY_PATH || '/usr/local/bin/presage_processor';
        
        if (!fs.existsSync(binaryPath)) {
            console.warn('Presage binary not found, using REST API fallback');
            return false;
        }
        
        this.process = spawn(binaryPath, [
            '--api-key', this.apiKey,
            '--mode', 'continuous',
            '--output', 'json'
        ]);
        
        this.process.stdout.on('data', (data) => {
            try {
                const result = JSON.parse(data.toString());
                this.handleResult(result);
            } catch (e) {
                // Handle non-JSON output
            }
        });
        
        this.process.stderr.on('data', (data) => {
            console.error('Presage error:', data.toString());
        });
        
        this.process.on('close', (code) => {
            console.log(`Presage process exited with code ${code}`);
        });
        
        return true;
    }
    
    sendFrame(frameData, callback) {
        if (!this.process) return;
        
        const frameId = Date.now().toString();
        this.callbacks.set(frameId, callback);
        
        this.process.stdin.write(JSON.stringify({
            id: frameId,
            frame: frameData
        }) + '\n');
    }
    
    handleResult(result) {
        const callback = this.callbacks.get(result.id);
        if (callback) {
            callback(result.data);
            this.callbacks.delete(result.id);
        }
    }
    
    stop() {
        if (this.process) {
            this.process.kill();
            this.process = null;
        }
    }
}

// ============================================
// SERVER STARTUP
// ============================================

server.listen(CONFIG.port, () => {
    console.log(`
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   🎧 ReadFlow Server Started                                 ║
║                                                              ║
║   REST API: http://localhost:${CONFIG.port}/api              ║
║   WebSocket: ws://localhost:${CONFIG.port}                   ║
║                                                              ║
║   Services:                                                  ║
║   • Presage:     ${CONFIG.presageApiKey ? '✅ Configured' : '⚠️  Not configured'}                    ║
║   • ElevenLabs:  ${CONFIG.elevenLabsApiKey ? '✅ Configured' : '⚠️  Not configured'}                    ║
║   • Gemini:      ${CONFIG.geminiApiKey ? '✅ Configured' : '⚠️  Not configured'}                    ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    `);
});

module.exports = { app, server, wss };
