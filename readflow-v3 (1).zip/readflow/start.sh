#!/bin/bash
#
# ReadFlow Quick Start Script
# This script helps you get ReadFlow running quickly
#

set -e

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         📖 ReadFlow - Quick Start Setup                      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "   Please install Node.js 18+ from: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version must be 18 or higher (found v$NODE_VERSION)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Install backend dependencies
echo ""
echo "📦 Installing backend dependencies..."
cd backend
npm install
cd ..

# Check for .env file
if [ ! -f backend/.env ]; then
    echo ""
    echo "⚙️  Creating .env file from template..."
    cp backend/.env.example backend/.env
    echo ""
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║  ⚠️  IMPORTANT: You need to add your API keys!              ║"
    echo "╠══════════════════════════════════════════════════════════════╣"
    echo "║                                                              ║"
    echo "║  Edit: backend/.env                                          ║"
    echo "║                                                              ║"
    echo "║  Get your keys from:                                         ║"
    echo "║  • Presage:    https://physiology.presagetech.com            ║"
    echo "║  • ElevenLabs: https://elevenlabs.io                         ║"
    echo "║  • Gemini:     https://aistudio.google.com/app/apikey        ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""
    read -p "Press Enter after adding your API keys to continue..."
fi

echo ""
echo "🚀 Starting ReadFlow..."
echo ""
echo "   Backend will run on: http://localhost:3001"
echo "   Frontend will run on: http://localhost:3000"
echo ""

# Start backend in background
cd backend
npm start &
BACKEND_PID=$!
cd ..

# Wait for backend to start
sleep 3

# Start frontend
echo ""
echo "📱 Starting frontend server..."

if command -v python3 &> /dev/null; then
    cd frontend
    python3 -m http.server 3000 &
    FRONTEND_PID=$!
    cd ..
elif command -v python &> /dev/null; then
    cd frontend
    python -m http.server 3000 &
    FRONTEND_PID=$!
    cd ..
else
    echo "⚠️  Python not found. Starting frontend with npx serve..."
    npx serve frontend -p 3000 &
    FRONTEND_PID=$!
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✅ ReadFlow is running!                                     ║"
echo "║                                                              ║"
echo "║  🌐 Open in browser: http://localhost:3000                   ║"
echo "║                                                              ║"
echo "║  Press Ctrl+C to stop                                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Handle shutdown
cleanup() {
    echo ""
    echo "Shutting down..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    exit 0
}

trap cleanup SIGINT SIGTERM

# Keep script running
wait
